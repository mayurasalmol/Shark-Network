<?xml version="1.0" encoding="UTF-8"?>

<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
  <xsl:template match="/">
	
	<html>
		<head></head>
		<body>
			<table border="1">
				<tr>
					<th>Artist</th>
					<th>Country</th>
				</tr>
				<xsl:for-each select="catalog/cd">
					<tr>
						<td> <xsl:value-of select="artist"/> </td>
						<td> <xsl:value-of select="country"/> </td>
					</tr>
				</xsl:for-each>
			</table>
			<hr/>
		<select>
			<xsl:for-each select="catalog/cd">
				 <option value="volvo"> <xsl:value-of select="artist"/></option>
			</xsl:for-each>
		</select>
		</body>
	</html>    

  </xsl:template>  
</xsl:stylesheet>









