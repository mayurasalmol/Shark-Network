 <!-- js in head and body -->
 <!DOCTYPE html>
 <html>

 <head>
 	<script>
 		function myFunction() {
 			document.getElementById("demo").innerHTML = "Paragraph changed from click me button";
 		}

 		function myFunction1() {
 			document.getElementById("demo").innerHTML = "Paragraph changed from try me button";
 		}
 	</script>
 </head>

 <body>

 	<h1>A Web Page</h1>
 	<p id="demo">A Paragraph</p>
 	<input type="button" onclick="myFunction()" name="click" value="click me">
 	<input type="button" onclick="myFunction1()" name="try" value="try me">

 </body>
 </html>
