function myFunction() {
	document.getElementById("demo").innerHTML = "Paragraph changed from click me button";
}

function myFunction1() {
	document.getElementById("demo").innerHTML = "Paragraph changed from try me button";
}	