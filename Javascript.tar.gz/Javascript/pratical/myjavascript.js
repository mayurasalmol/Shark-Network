	function myFunction1() {
			document.getElementById("demo").innerHTML = "getElementById";
		}

		function myFunction2() {
			document.write("document.write");;
		}

		function myFunction3() {
			window.alert("alert");
		}

		function myFunction4() {
			console.log("log");
		}