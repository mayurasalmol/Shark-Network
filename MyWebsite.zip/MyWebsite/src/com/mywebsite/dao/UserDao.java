package com.mywebsite.dao;

import java.sql.*;
import com.mywebsite.bean.*;

public class UserDao {
	public static Connection getConnection() {
		Connection con = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/test", "root", "sa");
		} catch (Exception e) {
			System.out.println(e);
		}
		return con;
	}

	public static int save(User u) {

		int status = 0;
		try {
			Connection con = getConnection();
			PreparedStatement ps = con.prepareStatement(
					"INSERT INTO `test`.`tblUser`(`name`, `password`, `mobile`, `gender`, `address`, `email`) VALUES (?,?,?,?,?,?);");
			ps.setString(1, u.getName());
			ps.setString(2, u.getPassword());
			ps.setString(3, u.getMobile());
			ps.setString(4, u.getGender());
			ps.setString(5, u.getAddress());
			ps.setString(6, u.getEmail());
			status = ps.executeUpdate();
		} catch (Exception e) {
			System.out.println(e);
		}
		return status;
	}

	public static boolean isAuthenticated(User u) {
		boolean isAuthentic = false;
		try {
			Connection con = getConnection();
			PreparedStatement ps = con.prepareStatement("select * from `test`.`tblUser` where email=? and password=?");
			ps.setString(1, u.getEmail());
			ps.setString(2, u.getPassword());
			ResultSet rs = ps.executeQuery();			
			isAuthentic = rs.next();
		} catch (Exception e) {
			System.out.println(e);
		}
		return isAuthentic;
	}
	
	public static User getUser(String email) {
		User u = null;
		try {
			Connection con = getConnection();
			PreparedStatement ps = con.prepareStatement("select * from `test`.`tblUser` where email=?");
			ps.setString(1, email);
			ResultSet rs = ps.executeQuery();			
	        while(rs.next()){  
	            u=new User();  
	            u.setId(rs.getInt("id"));  
	            u.setName(rs.getString("name"));  
	            u.setPassword(rs.getString("password"));  
	            u.setEmail(rs.getString("email"));  
	            u.setAddress(rs.getString("address"));  
	            u.setMobile(rs.getString("mobile"));  
	            u.setGender(rs.getString("gender"));  
	        }  
		} catch (Exception e) {
			System.out.println(e);
		}
		return u;
	}
}
