function validate()
{
	var type=document.getElementById("type").value;
	if(type=="14")
	{
		document.getElementById("item_id").value="Conference Fees - (Indian Author) - IEEE Member";
		document.getElementById("amount").value="75.20";
	}
	else if(type=="15")
	{
		document.getElementById("item_id").value="Conference Fees - (Indian Author) - Non IEEE Member";
		document.getElementById("amount").value="82.70";
	}
	else if(type=="16")
	{
		document.getElementById("item_id").value="Conference Fees - (Listener) ";
		document.getElementById("amount").value="30.10";
	}
	else if(type=="17")
	{
		document.getElementById("item_id").value="Conference Fees - (Foreign Author) - IEEE Member";
		document.getElementById("amount").value="400";
	}
	else if(type=="18")
	{
		document.getElementById("item_id").value="Conference Fees - (Foreign Author) - Non IEEE Member";
		document.getElementById("amount").value="450";
	}
	else if(type=="19")
	{
		document.getElementById("item_id").value="Conference Fees - UG/PG Student";
		document.getElementById("amount").value="60";
	}
}
